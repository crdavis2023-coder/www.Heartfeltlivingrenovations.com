import { useState } from 'react'

export default function Contact(){
  const [state,setState]=useState({name:'',email:'',phone:'',message:''})
  const [status,setStatus]=useState('idle')
  const onSubmit=async(e)=>{
    e.preventDefault(); setStatus('sending');
    try{
      const res=await fetch('/api/contact',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(state)})
      if(res.ok){ setStatus('sent'); setState({name:'',email:'',phone:'',message:''}) } else { setStatus('error') }
    }catch{ setStatus('error') }
  }
  return (
    <div className='mx-auto max-w-3xl'>
      <h1 className='text-3xl font-bold mb-4'>Contact Us</h1>
      <section className='contact-block p-4 bg-gray-50 rounded-md mb-6'>
        <p><strong>Email:</strong> <a href='mailto:crdavis39@heartfeltlivingrenovations.com'>crdavis39@heartfeltlivingrenovations.com</a></p>
        <p><strong>Phone:</strong> <a href='tel:(839)205-1101'>(839)205-1101</a></p>
      </section>
      <form onSubmit={onSubmit} className='space-y-4'>
        <input required placeholder='Your name' className='w-full border p-3 rounded' value={state.name} onChange={e=>setState({...state,name:e.target.value})}/>
        <input required type='email' placeholder='Your email' className='w-full border p-3 rounded' value={state.email} onChange={e=>setState({...state,email:e.target.value})}/>
        <input placeholder='Your phone' className='w-full border p-3 rounded' value={state.phone} onChange={e=>setState({...state,phone:e.target.value})}/>
        <textarea required placeholder='How can we help?' className='w-full border p-3 rounded min-h-[140px]' value={state.message} onChange={e=>setState({...state,message:e.target.value})}/>
        <button className='btn-primary px-4 py-2 rounded' disabled={status==='sending'}>{status==='sending'?'Sending…':'Send message'}</button>
        {status==='sent' && <p className='text-green-700'>Thanks! We’ll get back to you shortly.</p>}
        {status==='error' && <p className='text-red-700'>Something went wrong. You can also email us directly.</p>}
      </form>
    </div>
  )
}
