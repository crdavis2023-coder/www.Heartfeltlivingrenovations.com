import Link from 'next/link'

export default function Header(){ return (
  <header className="sticky top-0 z-30 bg-white/90 backdrop-blur shadow-sm border-b" role="banner">
    <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
      <div className="flex items-center space-x-3">
        <Link href="/"><a className="flex items-center space-x-3">
          <img src="/logo.png" alt="Heartfelt Living Renovations logo" className="h-12 w-auto rounded-md"/>
          <span className="text-lg font-extrabold text-brand">Heartfelt Living</span>
        </a></Link>
      </div>
      <nav aria-label="Main navigation" className="hidden md:flex items-center space-x-4 text-sm">
        <Link href="/"><a className="hover:underline">Home</a></Link>
        <Link href="/services"><a className="hover:underline">Services</a></Link>
        <Link href="/pricing"><a className="hover:underline">Pricing</a></Link>
        <Link href="/gallery"><a className="hover:underline">Gallery</a></Link>
        <Link href="/testimonials"><a className="hover:underline">Testimonials</a></Link>
        <Link href="/schedule"><a className="hover:underline">Schedule</a></Link>
        <Link href="/payments"><a className="hover:underline">Payments</a></Link>
        <Link href="/contact"><a className="px-3 py-1 rounded-md bg-accent text-white font-semibold">Contact</a></Link>
      </nav>
      <div className="hidden md:block text-sm">
        <a href="tel:(839)205-1101">(839)205-1101</a> • <a href="mailto:crdavis39@heartfeltlivingrenovations.com">crdavis39@heartfeltlivingrenovations.com</a>
      </div>
      <div className="md:hidden">
        <Link href="/contact"><a className="px-3 py-1 rounded-md bg-accent text-white font-semibold text-sm">Contact</a></Link>
      </div>
    </div>
  </header>
) }
