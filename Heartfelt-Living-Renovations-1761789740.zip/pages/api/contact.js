import sgMail from '@sendgrid/mail'

export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).json({error:'Method not allowed'})
  const {name='',email='',phone='',message=''}=req.body||{}
  if(!process.env.SENDGRID_API_KEY){ return res.status(500).json({error:'Missing SENDGRID_API_KEY'}) }
  const TO=process.env.CONTACT_TO_EMAIL||'crdavis39@heartfeltlivingrenovations.com'
  const FROM=process.env.CONTACT_FROM_EMAIL||'no-reply@heartfeltlivingrenovations.com'
  try{
    sgMail.setApiKey(process.env.SENDGRID_API_KEY)
    await sgMail.send({to:TO,from:FROM,subject:`New website inquiry from ${name||'Website Visitor'}`,
      text:`Name: ${name}\nEmail: ${email}\nPhone: ${phone}\n\nMessage:\n${message}`})
    return res.status(200).json({ok:true})
  }catch(err){ return res.status(500).json({error:err?.message||'Failed to send'}) }
}
