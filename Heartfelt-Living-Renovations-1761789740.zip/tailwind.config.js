/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./**/*.{js,jsx,ts,tsx}"],
  theme: { extend: { colors: { brand: '#7A1F3A', accent: '#F6A623', accent2: '#2B7FB6', violet: '#9B2FAE' } } },
  plugins: []
}
