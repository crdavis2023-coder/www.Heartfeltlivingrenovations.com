# Heartfelt Living Renovations — Website

Next.js + Tailwind site with scheduling, Stripe payments, contact form, legal pages, icons/manifest, and a lightbox portfolio.

## Setup
```bash
npm install
cp .env.local.example .env.local
# fill NEXT_PUBLIC_SITE_URL, STRIPE_SECRET_KEY, SMTP_* and SCHEDULER_IFRAME_URL
npm run dev
```

## Icons & Manifest
Replace placeholders in `/public` with real exports from your logo/icon:
- `android-chrome-192x192.png` (192x192), `android-chrome-512x512.png` (512x512)
- `apple-touch-icon.png` (180x180), `favicon.ico` (32x32 or 48x48)
Manifest: `/public/site.webmanifest` (theme color `#8A1C4A`).

## Portfolio Images
Put photos into `/public/portfolio/` and adjust `app/portfolio/page.tsx` image list.

## Push to GitHub
```bash
git init
git add .
git commit -m "Heartfelt site: theme + icons + manifest + gallery + legal + payments"
git branch -M main
git remote add origin https://github.com/YOUR-USER/heartfelt-living-renovations.git
git push -u origin main
```
