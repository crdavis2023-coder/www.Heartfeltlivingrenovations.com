/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}","./components/**/*.{js,ts,jsx,tsx}"],
  theme: { extend: {
    colors: {
      primary: { DEFAULT: "var(--color-primary)", foreground: "var(--color-primary-foreground)" },
      accent: { DEFAULT: "var(--color-accent)", foreground: "var(--color-accent-foreground)" },
      base: { DEFAULT: "var(--color-base)", foreground: "var(--color-base-foreground)" }
    },
    boxShadow: { soft: "0 10px 30px rgba(0,0,0,0.08)" }
  }},
  plugins: [],
};
