import "./globals.css";
import Link from "next/link";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Heartfelt Living Renovations LLC",
  description: "Custom renovations, structural repairs, and design-forward remodeling in South Carolina.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
        <link rel="manifest" href="/site.webmanifest" />
        <meta name="theme-color" content="#8A1C4A" />
      </head>
      <body className="min-h-screen flex flex-col">
        <header className="border-b bg-white sticky top-0 z-50">
          <div className="container flex items-center gap-6 h-16">
            <Link href="/" className="flex items-center gap-3 font-semibold">
              <img src="/logo.svg" alt="Heartfelt logo" className="h-8 w-auto" />
              <span>Heartfelt Living Renovations</span>
            </Link>
            <nav className="ml-auto hidden md:flex items-center gap-6">
              <Link href="/services" className="hover:text-primary">Services</Link>
              <Link href="/portfolio" className="hover:text-primary">Portfolio</Link>
              <Link href="/schedule" className="hover:text-primary">Schedule</Link>
              <Link href="/pay" className="hover:text-primary">Payments</Link>
              <Link href="/about" className="hover:text-primary">About</Link>
              <Link href="/contact" className="rounded-full bg-primary text-white px-4 py-2">Contact</Link>
            </nav>
          </div>
        </header>
        <main className="flex-1">{children}</main>
        <footer className="border-t mt-16">
          <div className="container py-10 grid sm:grid-cols-2 md:grid-cols-4 gap-8 text-sm">
            <div>
              <div className="font-semibold mb-3">Heartfelt Living Renovations LLC</div>
              <p>Email: <a className="text-primary" href="mailto:crdavis39@heartfeltlivingrenovations.com">crdavis39@heartfeltlivingrenovations.com</a></p>
              <p>Phone: <a className="text-primary" href="tel:+18037485811">(803) 748-5811</a></p>
            </div>
            <div>
              <div className="font-semibold mb-3">Company</div>
              <ul className="space-y-2">
                <li><Link className="hover:text-primary" href="/about">About</Link></li>
                <li><Link className="hover:text-primary" href="/services">Services</Link></li>
                <li><Link className="hover:text-primary" href="/portfolio">Portfolio</Link></li>
              </ul>
            </div>
            <div>
              <div className="font-semibold mb-3">Legal</div>
              <ul className="space-y-2">
                <li><Link className="hover:text-primary" href="/privacy">Privacy Policy</Link></li>
                <li><Link className="hover:text-primary" href="/terms">Terms of Service</Link></li>
                <li><Link className="hover:text-primary" href="/refund">Refund Policy</Link></li>
                <li><Link className="hover:text-primary" href="/service-agreement">Service Agreement</Link></li>
              </ul>
            </div>
            <div>
              <div className="font-semibold mb-3">Get in touch</div>
              <p className="mb-3">Have a project in mind? We’d love to hear about it.</p>
              <Link href="/contact" className="inline-block rounded-full bg-primary text-white px-4 py-2">Contact Us</Link>
            </div>
          </div>
          <div className="border-t py-4 text-center text-xs text-gray-500">
            © {new Date().getFullYear()} Heartfelt Living Renovations LLC. All rights reserved.
          </div>
        </footer>
      </body>
    </html>
  );
}
