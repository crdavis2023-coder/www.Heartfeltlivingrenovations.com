export default function Home() {
  return (
    <section>
      <div className="container py-16 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-extrabold text-base">Remodels Done Right—With Heart.</h1>
          <p className="mt-4 text-lg text-gray-700">
            Custom renovations, structural repairs, and design-forward remodeling built on craftsmanship, transparency, and care.
          </p>
          <div className="mt-6 flex gap-4">
            <a href="/schedule" className="rounded-full bg-primary text-white px-5 py-3">Book an Estimate</a>
            <a href="/portfolio" className="rounded-full border px-5 py-3">See Our Work</a>
          </div>
        </div>
        <div className="card p-4">
          <img src="/logo.svg" alt="Heartfelt Living Renovations" className="w-full h-auto"/>
        </div>
      </div>
    </section>
  );
}
