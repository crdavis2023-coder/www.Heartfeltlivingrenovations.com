"use client";
import { useState } from "react";

export const metadata = { title: "Portfolio - Heartfelt Living Renovations" };

const images = [
  { src: "/portfolio/kitchen-after.jpg", alt: "Kitchen Remodel - After" },
  { src: "/portfolio/kitchen-before.jpg", alt: "Kitchen Remodel - Before" },
  { src: "/portfolio/bath-after.jpg", alt: "Bathroom Remodel - After" },
  { src: "/portfolio/flooring-after.jpg", alt: "Flooring Upgrade - After" },
];

export default function Page(){
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState<number>(0);

  function show(i:number){ setActive(i); setOpen(true); }
  function close(){ setOpen(false); }

  return (
    <section className="container py-12">
      <h1 className="text-3xl font-bold mb-6">Portfolio</h1>
      <p className="text-gray-700 mb-8">A few representative shots. Ask for full before/after galleries and references.</p>
      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
        {images.map((img, i) => (
          <button key={i} onClick={()=>show(i)} className="card overflow-hidden group">
            <img src={img.src} alt={img.alt} className="w-full h-56 object-cover group-hover:scale-105 transition-transform" />
            <div className="p-3 text-sm">{img.alt}</div>
          </button>
        ))}
      </div>

      {open && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center" onClick={close}>
          <div className="relative max-w-5xl w-[95%]">
            <img src={images[active].src} alt={images[active].alt} className="w-full h-auto rounded-2xl" />
            <button onClick={(e)=>{e.stopPropagation(); setOpen(false);}} className="absolute top-2 right-2 bg-white rounded-full px-3 py-1">Close</button>
            <div className="absolute inset-x-0 bottom-2 flex justify-between px-2">
              <button onClick={(e)=>{e.stopPropagation(); setActive((active-1+images.length)%images.length);}} className="bg-white/90 rounded-full px-3 py-1">Prev</button>
              <button onClick={(e)=>{e.stopPropagation(); setActive((active+1)%images.length);}} className="bg-white/90 rounded-full px-3 py-1">Next</button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
