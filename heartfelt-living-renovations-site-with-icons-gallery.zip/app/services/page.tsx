export const metadata = { title: "Services - Heartfelt Living Renovations" };
export default function Page() {
  return (
    <section className="container py-12 prose max-w-3xl">
      <h1>Services</h1>
      <p>Kitchens • Bathrooms • Flooring • Painting • Drywall • Framing • Decks • Doors/Windows • Design consultations.</p>
    </section>
  );
}
