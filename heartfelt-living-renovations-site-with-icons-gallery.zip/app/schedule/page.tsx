export const metadata = { title: "Schedule - Heartfelt Living Renovations" };
export default function Page(){
  const src = process.env.SCHEDULER_IFRAME_URL || "";
  return (
    <section className="container py-12">
      <h1 className="text-3xl font-bold mb-4">Schedule an Estimate</h1>
      {!src ? <p>Add your scheduling iframe URL in .env.local (SCHEDULER_IFRAME_URL).</p> : <iframe src={src} className="w-full h-[800px] border rounded-2xl"></iframe>}
    </section>
  );
}
