import { NextRequest, NextResponse } from "next/server";
import nodemailer from "nodemailer";

export async function POST(req: NextRequest){
  try{
    const body = await req.json();
    const { name, email, phone, message } = body || {};
    if(!name || !email || !phone || !message) return NextResponse.json({ error: "Missing fields" }, { status: 400 });

    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: false,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    });

    const info = await transporter.sendMail({
      from: process.env.SMTP_FROM,
      to: process.env.COMPANY_EMAIL,
      subject: "New Project Inquiry",
      text: `Name: ${name}\nEmail: ${email}\nPhone: ${phone}\n\n${message}`,
    });

    return NextResponse.json({ ok: true, id: info.messageId });
  } catch(e:any){
    return NextResponse.json({ error: e.message || "Mail error" }, { status: 500 });
  }
}
