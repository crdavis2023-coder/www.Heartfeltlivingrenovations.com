import Stripe from "stripe";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", { apiVersion: "2024-06-20" as any });
    const { amount } = await req.json();
    const site = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
    if (!amount || amount < 50) return NextResponse.json({ error: "Invalid amount." }, { status: 400 });

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card", "us_bank_account", "link"],
      allow_promotion_codes: true,
      line_items: [{
        price_data: { currency: "usd", unit_amount: amount, product_data: { name: "Project Payment" } },
        quantity: 1
      }],
      success_url: `${site}/pay?status=success`,
      cancel_url: `${site}/pay?status=cancelled`,
    });
    return NextResponse.json({ url: session.url });
  } catch (e:any) {
    return NextResponse.json({ error: e.message || "Checkout error" }, { status: 500 });
  }
}
