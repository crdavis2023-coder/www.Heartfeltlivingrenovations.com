"use client";
import { useState } from "react";

export default function Pay(){
  const [loading,setLoading]=useState(false);
  const [amount,setAmount]=useState(10000);

  async function createCheckout(){
    setLoading(true);
    try{
      const res = await fetch("/api/checkout", { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ amount }) });
      const data = await res.json();
      if(data.url){ window.location.href = data.url; } else { alert(data.error || "Unable to start checkout."); }
    } finally { setLoading(false); }
  }

  return (
    <section className="container py-12 max-w-xl">
      <h1 className="text-3xl font-bold mb-2">Secure Payments</h1>
      <p className="text-gray-700 mb-6">Pay deposits or invoices online (cards, ACH, wallets via Stripe Checkout).</p>
      <label className="block mb-2 font-medium">Amount (USD cents)</label>
      <input type="number" className="w-full border rounded-xl p-3 mb-4" value={amount} onChange={e=>setAmount(parseInt(e.target.value||'0',10))}/>
      <button onClick={createCheckout} disabled={loading} className="rounded-full bg-primary text-white px-5 py-3">
        {loading ? "Starting..." : "Pay with Stripe"}
      </button>
    </section>
  );
}
