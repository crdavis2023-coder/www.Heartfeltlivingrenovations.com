"use client";
import { useState } from "react";

export default function ContactPage(){
  const [form, setForm] = useState({ name:"", email:"", phone:"", message:"" });
  const [status, setStatus] = useState<string | null>(null);

  async function submit(e: React.FormEvent){
    e.preventDefault();
    setStatus("Sending...");
    const res = await fetch("/api/contact", { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(form) });
    const data = await res.json();
    setStatus(data.ok ? "Thanks! We’ll be in touch shortly." : (data.error || "Failed to send."));
  }

  return (
    <section className="container py-12 max-w-2xl">
      <h1 className="text-3xl font-bold mb-6">Contact Us</h1>
      <form onSubmit={submit} className="grid gap-4">
        {["name","email","phone"].map((k) => (
          <input key={k} required className="border rounded-xl p-3" placeholder={k[0].toUpperCase()+k.slice(1)} value={(form as any)[k]} onChange={e=>setForm({...form, [k]: e.target.value})}/>
        ))}
        <textarea required className="border rounded-xl p-3 h-32" placeholder="Tell us about your project..." value={form.message} onChange={e=>setForm({...form, message:e.target.value})}/>
        <button className="rounded-full bg-primary text-white px-5 py-3">Send</button>
      </form>
      {status && <p className="mt-4 text-sm">{status}</p>}
    </section>
  );
}
