export const metadata = { title: "About - Heartfelt Living Renovations" };
export default function Page() {
  return (
    <section className="container py-12 prose max-w-3xl">
      <h1>About</h1>
      <p>20+ years of hands-on trade experience with modern project management for a stress-free remodel.</p>
    </section>
  );
}
